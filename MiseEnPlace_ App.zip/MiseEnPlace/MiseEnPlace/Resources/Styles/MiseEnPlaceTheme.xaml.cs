namespace MiseEnPlace.Resources.Styles;

public partial class MiseEnPlaceTheme : ResourceDictionary
{
	public MiseEnPlaceTheme()
	{
		InitializeComponent();
	}
}