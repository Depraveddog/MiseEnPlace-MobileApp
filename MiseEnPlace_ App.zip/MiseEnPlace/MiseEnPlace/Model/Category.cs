﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MiseEnPlace.Model
{
    public class Category // model for category used in the selection page 
    {
        public string Name { get; set; }
        public List<string> Items { get; set; }
        public Color Color { get; set; }
        public string Image { get; set; }
    }
}
