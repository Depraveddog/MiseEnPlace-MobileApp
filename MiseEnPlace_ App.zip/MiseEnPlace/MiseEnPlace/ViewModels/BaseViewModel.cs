﻿using System.ComponentModel;
using System.Runtime.CompilerServices;


namespace MiseEnPlace.ViewModels
{
    public class BaseViewModel : INotifyPropertyChanged // experimenting with Self created MVVM rather than using MVVM package
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public readonly HttpClient Client = new HttpClient(); // Httpclient we will be using throughout to make our api calls
        
        public BaseViewModel()
        { 
         Client.Timeout = TimeSpan.FromHours(1); // setting Client timeout to one hour so will not have errors when designing xaml 
        }

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
}
