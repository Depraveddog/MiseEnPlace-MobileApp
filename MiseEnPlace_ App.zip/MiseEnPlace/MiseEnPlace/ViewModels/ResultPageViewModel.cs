﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using MiseEnPlace.Model;
using Newtonsoft.Json;

namespace MiseEnPlace.ViewModels
{
    public  class ResultPageViewModel : BaseViewModel // experiment on MVVM, creating a individual baseviewmodel to notify when property changes
    {
        private const string apiKey = "700d5c31506842aa9d53d52a6b421f2f"; //storing Spoonacular API key 
        
        private bool _isBusy; // declaring a boolean for activity bar
        public bool IsBusy  // get and set value in isBusy
        {
            get => _isBusy; 
            set
            {
                _isBusy = value;
                OnPropertyChanged();
            }
        }
        private int _activityHeight; // declaring a fixed height for activity bar
        public int ActivityHeight// get and set value in activityheight 
        {
            get => _activityHeight;
            set
            {
                _activityHeight = value;
                OnPropertyChanged();
            }

        }
        public  ResultPageViewModel(string query) //constructor taking it http client and search query as a arguments. 
        {
             _= ApiCalling(query); // query as a argument for search query
        }
        public async Task ApiCalling(string query)// task that is asynchronous that has a parameter that whill be passed into the api call and to execute the api call
        {
            IsBusy= true; // when task starts, Activity bar would be active till the task pulls the recipe
            ActivityHeight = 600; // when task runs, activity height value would be 600, activity bar will be placed in the center
            string recipeURL = $"https://api.spoonacular.com/recipes/findByIngredients?ingredients={query}&number=2&apiKey={apiKey}"; // setting query request along with API key 
            try
            {
                var recipeResponse = await Client.GetAsync(recipeURL);
                // using await, so that task will not continue until http request and response is received
                recipeResponse.EnsureSuccessStatusCode(); //response status in the range of 200-299 if not a exception will be displayed
                var recipeJson = await recipeResponse.Content.ReadAsStringAsync(); // response content is read as a string 
                var recipeTags = JsonConvert.DeserializeObject<List<Recipe>>(recipeJson); // Newtonsoft Package to deserialize json to a list of object
                MyRecipes = recipeTags;

                List<FullRecipe> recipeDetails = new List<FullRecipe>();

                foreach (var recipe in recipeTags)
                {
                    string id = recipe.Id.ToString();
                    string detailsURL = $"https://api.spoonacular.com/recipes/{id}/information?apiKey={apiKey}";
                    try
                    {
                        var detailsResponse = await Client.GetAsync(detailsURL);
                        detailsResponse.EnsureSuccessStatusCode();
                        var detailsJson = await detailsResponse.Content.ReadAsStringAsync();
                        var details = JsonConvert.DeserializeObject<FullRecipe>(detailsJson);
                        recipeDetails.Add(details);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Error retrieving recipe details: {ex.Message}");
                    }
                }


                foreach (var recipe in recipeDetails) // since the api we are using focuses more on html, this is to remove the html tags
                {
                    string summary = recipe.Summary;
                    summary = Regex.Replace(summary, "<.*?>", string.Empty); //using System.Text.RegularExpressions 
                    recipe.Summary = summary;
                }
                foreach (var recipe in recipeDetails) // since the api we are using, returns the ingredients in lowercase, we used this to capitialise the first letter
                {
                    foreach (var ingredient in recipe.ExtendedIngredients)
                    {
                        string name = CultureInfo.CurrentCulture.TextInfo.ToTitleCase(ingredient.Name.ToLower()); //
                        ingredient.Name = name;
                    }
                }
                foreach (var recipe in recipeDetails) // since the api we are using focuses more on html, this is to remove the of the html tags
                {
                    string instructions = recipe.Instructions;
                    instructions = Regex.Replace(instructions, "<.*?>", string.Empty);  
                    recipe.Instructions = instructions  ;
                }

                MyFullRecipes = recipeDetails;
                IsBusy = false;
                ActivityHeight = 0;
                }
                catch (Exception ex) // if exception,display the error retrieving
                {
                Console.WriteLine($"Error retrieving Recipes {ex.Message}");
                }
        }

        private List<Recipe> _myRecipes; //declaring list variable and storing it in Recipe model
        private List<FullRecipe> _myFullRecipes; //declaring list variable and storing it in FullRecipe model

        private FullRecipe myDetails; // declaring class myDetails under FullRecipe model
        public FullRecipe MyDetails  // getting the values pull from API mydetails and storing them in model class
        {
          get => myDetails;
          set
             {
                myDetails = value;
                OnPropertyChanged(nameof(MyDetails)); // when OnProperyChanged is active, it updates the values 
             }
        }
        public List<Recipe> MyRecipes // getting the values pull from API myRecipes and storing them in model class
        {
          get => _myRecipes; 
          set
             {
               _myRecipes = value;
                OnPropertyChanged(); // when OnProperyChanged is active, it updates the values 
             }
        }
        public List<FullRecipe> MyFullRecipes // getting the values pull from API MyFullRecipes and storing them in model class
        {
            get => _myFullRecipes;
            set
            {
                _myFullRecipes = value;
                OnPropertyChanged(); 
            }
        }


    }
}
