using MiseEnPlace.ViewModels;
using MiseEnPlace.Model;
using MiseEnPlace.Pages;


namespace MiseEnPlace;

public partial class ResultPage : ContentPage
{
	private string query;

    private ResultPageViewModel resultPageViewModel;
	public ResultPage(string query)
	{
		InitializeComponent();
		this.query = query;
        resultPageViewModel = new ResultPageViewModel(this.query);
        BindingContext = resultPageViewModel;
	}
    protected override void OnAppearing() //creating an OnAppearing method to prevent httpclient issues as we are using HttpClient method more than once.
    {
        base.OnAppearing();
    }
    private async void Button_Clicked(object sender, EventArgs e) // a method to identify and assign the correct "view model" content when clicked
    {
        var button = (Button)sender;
        var frame = button.Parent as Frame;
        var grid = frame.Parent as Grid;
        var frame2 = grid.Parent as Frame;
        var item = (FullRecipe)frame2.BindingContext;
        var recipePage = new RecipePage(item);
        await Navigation.PushAsync(recipePage);
    }
}