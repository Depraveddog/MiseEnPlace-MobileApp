﻿namespace MiseEnPlace;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
